from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
from bson import ObjectId
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import threading
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/womensafety'
UPLOAD_FOLDER = './uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = {'mp4'}
mongo = PyMongo(app)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Placeholder for alert status
alert_active = False

stop_sending = False  # Flag to control email sending

# Gmail SMTP configuration
gmail_user = 'notifysunilkumar@gmail.com'  # Update with your Gmail email address
gmail_password = 'nifpbmozikvptqoz'

def send_alert_email(subject, body, emergency_contact_email, video_file_path=None):
    try:
        msg = MIMEMultipart()
        msg['From'] = gmail_user
        msg['To'] = emergency_contact_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        if video_file_path:
            with open(video_file_path, 'rb') as video_file:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(video_file.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename={os.path.basename(video_file_path)}')
                msg.attach(part)

        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(gmail_user, gmail_password)
        server.sendmail(gmail_user, emergency_contact_email, msg.as_string())
        server.close()
        print('Email sent successfully')
    except Exception as e:
        print(f'Failed to send email: {e}')
        raise

def start_sending_emails(location):
    global stop_sending
    while not stop_sending:
        contact = mongo.db.emergency_contacts.find_one()
        if contact:
            emergency_contact_email = contact.get('email')
            if emergency_contact_email:
                send_alert_email('Emergency Alert: Current Location', f'Emergency! Current location: {location}', emergency_contact_email)
        threading.Event().wait(2)
    print("Email thread stopped")  # Add this for debugging

@app.route('/add_emergency_contact', methods=['POST'])
def add_emergency_contact():
    data = request.json
    name = data.get('name')
    phone = data.get('phone')
    email = data.get('email')
    
    if name and phone:
        contact = {
            'name': name,
            'phone': phone,
            'email': email
        }
        result = mongo.db.emergency_contacts.insert_one(contact)
        inserted_id = str(result.inserted_id)
        return jsonify({'message': 'Emergency contact added successfully', 'id': inserted_id}), 201
    else:
        return jsonify({'error': 'Name and phone are required'}), 400

@app.route('/get_emergency_contact', methods=['GET'])
def get_emergency_contact():
    contact = mongo.db.emergency_contacts.find_one()
    if contact:
        contact['_id'] = str(contact['_id'])
        return jsonify(contact)
    else:
        return jsonify({'error': 'Emergency contact not found'}), 404

@app.route('/alert_message', methods=['POST'])
def alert_message():
    global stop_sending

    data = request.json
    location = data.get('location')
    
    stop_sending = False

    if location:
        threading.Thread(target=start_sending_emails, args=(location,)).start()
        return jsonify({'message': 'Alert message sending started successfully'}), 200
    else:
        return jsonify({'error': 'Location data not found'}), 400

@app.route('/stop_alert_message', methods=['POST'])
def stop_alert_message():
    global stop_sending
    stop_sending = True
    send_final_alert_message()
    return jsonify({'message': 'Alert message sending stopped successfully'}), 200

def send_final_alert_message():
    final_message = "I am safe now."
    contact = mongo.db.emergency_contacts.find_one()
    if contact:
        emergency_contact_email = contact.get('email')
        if emergency_contact_email:
            send_alert_email('Final Alert', final_message, emergency_contact_email)

@app.route('/report_crime_area', methods=['POST'])
def report_crime_area():
    data = request.json
    latitude = data.get('latitude')
    longitude = data.get('longitude')

    if latitude is not None and longitude is not None:
        crime_area = {'latitude': latitude, 'longitude': longitude}
        result = mongo.db.crime_areas.insert_one(crime_area)
        inserted_id = str(result.inserted_id)
        return jsonify({'message': 'Crime area reported successfully', 'id': inserted_id}), 200
    else:
        return jsonify({'error': 'Latitude and longitude are required'}), 400
    
@app.route('/get_crime_areas', methods=['GET'])
def get_crime_areas():
    crime_areas = list(mongo.db.crime_areas.find({}, {'_id': 0}))
    return jsonify(crime_areas), 200

@app.route('/receive_location', methods=['POST'])
def receive_location():
    data = request.get_json()
    latitude = data.get('latitude')
    longitude = data.get('longitude')

    if latitude is not None and longitude is not None:
        in_crime_area = check_crime_area(latitude, longitude)
        if in_crime_area:
            send_alert_message(f'Alert: You are in a reported crime area at latitude {latitude}, longitude {longitude}.')
        return jsonify({'message': 'Location received.'}), 200
    else:
        return jsonify({'error': 'Invalid location data'}), 400

def check_crime_area(latitude, longitude):
    crime_areas = mongo.db.crime_areas.find()
    for area in crime_areas:
        area_latitude = area.get('latitude')
        area_longitude = area.get('longitude')
        if abs(latitude - area_latitude) < 0.01 and abs(longitude - area_longitude) < 0.01:
            return True
    return False

@app.route('/send_video', methods=['POST'])
def send_video():
    if 'video' not in request.files:
        return jsonify({'error': 'No video file provided'}), 400
    
    video_file = request.files['video']
    if video_file.filename == '':
        return jsonify({'error': 'Empty filename provided for video'}), 400

    if not allowed_file(video_file.filename):
        return jsonify({'error': 'File type not allowed'}), 400

    try:
        video_file_path = os.path.join(UPLOAD_FOLDER, secure_filename(video_file.filename))
        video_file.save(video_file_path)
        contacts = mongo.db.emergency_contacts.find()
        for contact in contacts:
            emergency_contact_email = contact.get('email')
            if emergency_contact_email:
                send_alert_email('Video Alert Message', 'Emergency! Video from the incident location.', emergency_contact_email, video_file_path)
        os.remove(video_file_path)  # Clean up the saved video file after sending
        return jsonify({'message': 'Video sent successfully'}), 200
    except Exception as e:
        print(f'Failed to send video: {e}')
        return jsonify({'error': f'Failed to send video: {e}'}), 500

if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(host='0.0.0.0', port=5000)
