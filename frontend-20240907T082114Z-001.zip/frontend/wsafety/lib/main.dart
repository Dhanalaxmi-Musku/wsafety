import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:camera/camera.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final cameras = await availableCameras();
  final firstCamera = cameras.first;
  runApp(SafetyApp(camera: firstCamera));
}

class SafetyApp extends StatelessWidget {
  final CameraDescription camera;

  const SafetyApp({Key? key, required this.camera}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Safety App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SafetyScreen(camera: camera),
    );
  }
}

class SafetyScreen extends StatefulWidget {
  final CameraDescription camera;

  const SafetyScreen({Key? key, required this.camera}) : super(key: key);

  @override
  _SafetyScreenState createState() => _SafetyScreenState();
}

class _SafetyScreenState extends State<SafetyScreen> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture;
  List<Map<String, double>> crimeAreas = [];
  late StreamSubscription<Position> positionStream;
  bool alertActive = false;

  @override
  void initState() {
    super.initState();
    _controller = CameraController(
      widget.camera,
      ResolutionPreset.medium,
    );

    _initializeControllerFuture = _controller.initialize();
    fetchCrimeAreas();
    startLocationUpdates();
  }

  @override
  void dispose() {
    _controller.dispose();
    positionStream.cancel();
    super.dispose();
  }

  void startLocationUpdates() {
    positionStream = Geolocator.getPositionStream().listen((Position position) {
      checkLocationAgainstCrimeAreas(position);
    });
  }

  void fetchCrimeAreas() async {
    final url =
        'http://192.168.1.8:5000/get_crime_areas'; // Update with your server IP
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      List<Map<String, double>> areas = [];
      for (var area in data) {
        areas.add({
          'latitude': double.parse(area['latitude'].toString()),
          'longitude': double.parse(area['longitude'].toString()),
        });
      }
      setState(() {
        crimeAreas = areas;
      });
    } else {
      print('Failed to fetch crime areas');
    }
  }

  void checkLocationAgainstCrimeAreas(Position position) async {
    try {
      bool isInCrimeArea = false;

      for (Map<String, double> area in crimeAreas) {
        double areaLatitude = area['latitude']!;
        double areaLongitude = area['longitude']!;

        double distanceInMeters = await Geolocator.distanceBetween(
          position.latitude,
          position.longitude,
          areaLatitude,
          areaLongitude,
        );

        // Check if distance is within 1km (1000 meters)
        if (distanceInMeters <= 1000) {
          isInCrimeArea = true;
          break;
        }
      }

      if (isInCrimeArea) {
        displayAlert('You are in a crime area.');
      } else {
        displayAlert('Area is crime free.');
      }
    } catch (e) {
      print('Error: $e');
      displayAlert('Failed to check crime areas.');
    }
  }

  void displayAlert(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Area Crime Status'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> startAlertMessages() async {
    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      print('Location permission denied.');
      return;
    }

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    final url = 'http://192.168.1.8:5000/alert_message';
    final response = await http.post(
      Uri.parse(url),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8'
      },
      body: jsonEncode(<String, dynamic>{
        'location': {
          'latitude': position.latitude,
          'longitude': position.longitude
        }
      }),
    );

    if (response.statusCode == 200) {
      setState(() {
        alertActive = true;
      });
      displayAlert('Alert messages started');
      await _takeVideo(); // Start video recording after alert message
    } else {
      print('Error starting alert messages');
    }
  }

  void stopAlertMessages() async {
    final url = 'http://192.168.1.8:5000/stop_alert_message';
    final response = await http.post(Uri.parse(url));

    if (response.statusCode == 200) {
      setState(() {
        alertActive = false;
      });
      displayAlert('Alert messages stopped');
    } else {
      print('Error stopping alert messages');
    }
  }

  Future<void> _takeVideo() async {
    try {
      await _initializeControllerFuture;

      // Start video recording
      await _controller.startVideoRecording();

      // Wait for some time to record video (e.g., 10 seconds)
      await Future.delayed(Duration(seconds: 10));

      // Stop video recording and get the video file
      final XFile videoFile = await _controller.stopVideoRecording();

      // Retrieve video file bytes
      final Uint8List videoBytes = await videoFile.readAsBytes();

      print('Video recorded and captured');
      _sendVideo(videoBytes);
    } catch (e) {
      print('Error during video recording: $e');
    }
  }

  void _sendVideo(Uint8List videoBytes) async {
    final url = 'http://192.168.1.8:5000/send_video';
    var request = http.MultipartRequest('POST', Uri.parse(url));
    request.files.add(http.MultipartFile.fromBytes(
      'video',
      videoBytes,
      filename: 'video.mp4',
    ));

    try {
      var streamedResponse = await request.send();
      if (streamedResponse.statusCode == 200) {
        print('Video sent successfully');
      } else {
        print('Failed to send video: ${streamedResponse.statusCode}');
      }
    } catch (e) {
      print('Error sending video: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Women Safety'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 20.0,
          crossAxisSpacing: 20.0,
          children: [
            buildCard(context, 'Alert Message',
                alertActive ? Colors.red : Colors.grey, Icons.warning, () {
              if (!alertActive) {
                startAlertMessages();
              } else {
                stopAlertMessages();
              }
            }),
            buildCard(context, 'SOS', Colors.orange, Icons.dangerous, () async {
              final url = 'http://192.168.1.8:5000/get_emergency_contact';
              final response = await http.get(Uri.parse(url));
              if (response.statusCode == 200) {
                var data = jsonDecode(response.body);
                String emergencyContact = data['phone'];
                launch('tel:$emergencyContact');
              } else {
                print('Error fetching emergency contact');
              }
            }),
            buildCard(context, 'Report Crime Area', Colors.yellow, Icons.report,
                () {
              reportCrimeArea();
            }),
            buildCard(context, 'Crime Areas', Colors.green, Icons.location_on,
                () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => CrimeAreasScreen()));
            }),
            buildCard(context, 'Area Crime Status', Colors.blue,
                Icons.location_searching, () {
              checkAreaCrimeStatus();
            }),
            buildCard(context, 'Help', Colors.purple, Icons.help, () {
              // Implement Help functionality
            }),
            buildCard(
                context, 'Add Emergency Contact', Colors.teal, Icons.person_add,
                () {
              showDialog(
                  context: context, builder: (context) => AddContactDialog());
            }),
          ],
        ),
      ),
    );
  }

  Widget buildCard(BuildContext context, String label, Color color,
      IconData icon, VoidCallback onPressed) {
    return Card(
      color: color,
      child: InkWell(
        onTap: onPressed,
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 50,
                color: Colors.white,
              ),
              SizedBox(height: 20),
              Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> checkAreaCrimeStatus() async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    checkLocationAgainstCrimeAreas(position);
  }

  Future<void> reportCrimeArea() async {
    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      print('Location permission denied.');
      return;
    }

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    final url = 'http://192.168.1.8:5000/report_crime_area';
    final response = await http.post(
      Uri.parse(url),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, dynamic>{
        'latitude': position.latitude,
        'longitude': position.longitude,
      }),
    );

    if (response.statusCode == 201) {
      displayAlert('Crime area reported');
    } else {
      displayAlert('Failed to report crime area');
    }
  }
}

class CrimeAreasScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Crime Areas'),
      ),
      body: Center(
        child: Text('Display crime areas on map here'),
      ),
    );
  }
}

class AddContactDialog extends StatefulWidget {
  @override
  _AddContactDialogState createState() => _AddContactDialogState();
}

class _AddContactDialogState extends State<AddContactDialog> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Add Emergency Contact'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _nameController,
            decoration: InputDecoration(labelText: 'Name'),
          ),
          TextField(
            controller: _phoneController,
            decoration: InputDecoration(labelText: 'Phone'),
          ),
          TextField(
            controller: _emailController,
            decoration: InputDecoration(labelText: 'Email'),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () async {
            final url = 'http://192.168.1.8:5000/add_emergency_contact';
            final response = await http.post(
              Uri.parse(url),
              headers: <String, String>{
                'Content-Type': 'application/json; charset=UTF-8',
              },
              body: jsonEncode(<String, String>{
                'name': _nameController.text,
                'phone': _phoneController.text,
                'email': _emailController.text,
              }),
            );

            if (response.statusCode == 201) {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Contact added successfully')),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Failed to add contact')),
              );
            }
          },
          child: Text('Save'),
        ),
        TextButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text('Cancel'),
        ),
      ],
    );
  }
}
